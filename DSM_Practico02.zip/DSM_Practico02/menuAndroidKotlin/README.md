# menuAndroidKotlin
Un menú en Andoid Kotlin, para navegar entre pantallas. 

![Image text](https://github.com/AlexanderSiguenza/menuAndroidKotlin/blob/main/img/menu.png)
