package com.example.menukotlin.datos


class Nota {
    fun key(key: String?) {
    }
    var nombre: String? = null
    var n1: String? = null
    var n2: String? = null
    var n3: String? = null
    var n4: String? = null
    var n5: String? = null
    var key: String? = null

    var not: MutableMap<String, Boolean> = HashMap()
    constructor() {}
    constructor(nombre: String?, n1: String?,n2: String?,n3: String?,n4: String?,n5: String?) {
        this.nombre = nombre
        this.n1 = n1
        this.n2 = n2
        this.n3 = n3
        this.n4 = n4
        this.n5 = n5
    }

    fun toMap(): Map<String, Any?> {
        return mapOf(
            "nombre" to nombre,
            "n1" to n1,
            "n2" to n2,
            "n3" to n3,
            "n4" to n4,
            "n5" to n5,
            "key" to key,
            "not" to not
        )
    }
}