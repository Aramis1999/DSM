package com.example.menukotlin.datos
import android.app.Activity
import com.example.menukotlin.datos.Nota
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.menukotlin.R

class AdaptadorNota(private val context: Activity, var notas: List<Nota>):
    ArrayAdapter<Nota?>(context, R.layout.nota_layout, notas)
    {
        override fun getView(position: Int, view: View?, parent: ViewGroup): View {
// Método invocado tantas veces como elementos tenga la coleccion personas
// para formar a cada item que se visualizara en la lista personalizada
            val layoutInflater = context.layoutInflater
            var rowview: View? = null
// optimizando las diversas llamadas que se realizan a este método
// pues a partir de la segunda llamada el objeto view ya viene formado
// y no sera necesario hacer el proceso de "inflado" que conlleva tiempo y
// desgaste de bateria del dispositivo
            rowview = view ?: layoutInflater.inflate(R.layout.nota_layout, null)
            val tvNombre = rowview!!.findViewById<TextView>(R.id.tvNombre)
            val tvN1 = rowview.findViewById<TextView>(R.id.tvN1)
            val tvN2 = rowview.findViewById<TextView>(R.id.tvN2)
            val tvN3 = rowview.findViewById<TextView>(R.id.tvN3)
            val tvN4 = rowview.findViewById<TextView>(R.id.tvN4)
            val tvN5 = rowview.findViewById<TextView>(R.id.tvN5)
            val tvProm = rowview.findViewById<TextView>(R.id.tvProm)

            tvNombre.text = "nombre : " + notas[position].nombre
            tvN1.text = "nota 1 : " + notas[position].n1
            tvN2.text = "nota 2 : " + notas[position].n2
            tvN3.text = "nota 3 : " + notas[position].n3
            tvN4.text = "nota 4 : " + notas[position].n4
            tvN5.text = "nota 5 : " + notas[position].n5

            var nota1 = notas[position].n1.toString().toFloat()
            var nota2 = notas[position].n2.toString().toFloat()
            var nota3 = notas[position].n3.toString().toFloat()
            var nota4 = notas[position].n4.toString().toFloat()
            var nota5 = notas[position].n5.toString().toFloat()

            var resultado = (nota1 + nota2 + nota3 + nota4 +nota5) / 5
            if (resultado >= 6){
                tvN5.text = "Promedio : " + resultado + " Aprobado"
            }else{
                tvN5.text = "Promedio : " + resultado + " Reprobado"
            }

            return rowview
        }
    }