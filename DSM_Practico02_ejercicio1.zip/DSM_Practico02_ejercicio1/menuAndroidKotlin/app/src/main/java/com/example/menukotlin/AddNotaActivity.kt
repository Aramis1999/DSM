package com.example.menukotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.menukotlin.datos.Nota
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddNotaActivity : AppCompatActivity() {


    lateinit var nombre : EditText
    lateinit var n1 : EditText
    lateinit var n2 : EditText
    lateinit var n3 : EditText
    lateinit var n4 : EditText
    lateinit var n5 : EditText
    private var key = ""
    private var accion = ""
    lateinit var res : TextView
    lateinit var pas : TextView

    private lateinit var database:DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_nota)
        inicializar()
    }

    private fun inicializar() {
        nombre = findViewById<EditText>(R.id.nombre)
        n1 = findViewById<EditText>(R.id.editNota1)
        n2 = findViewById<EditText>(R.id.editNota2)
        n3 = findViewById<EditText>(R.id.editNota3)
        n4 = findViewById<EditText>(R.id.editNota4)
        n5 = findViewById<EditText>(R.id.editNota5)
        res = findViewById((R.id.textNota))
        pas = findViewById((R.id.textPaso))

        val nombre = findViewById<EditText>(R.id.nombre)
        val n1 = findViewById<EditText>(R.id.editNota1)
        val n2 = findViewById<EditText>(R.id.editNota2)
        val n3 = findViewById<EditText>(R.id.editNota3)
        val n4 = findViewById<EditText>(R.id.editNota4)
        val n5 = findViewById<EditText>(R.id.editNota5)

// Obtención de datos que envia actividad anterior
        val datos: Bundle? = intent.getExtras()
        if (datos != null) {
            key = datos.getString("key").toString()
        }
        if (datos != null) {
            nombre.setText(intent.getStringExtra("nombre").toString())
        }
        if (datos != null) {
            n1.setText(intent.getStringExtra("n1").toString())
        }
        if (datos != null) {
            n2.setText(intent.getStringExtra("n2").toString())
        }
        if (datos != null) {
            n3.setText(intent.getStringExtra("n3").toString())
        }
        if (datos != null) {
            n4.setText(intent.getStringExtra("n4").toString())
        }
        if (datos != null) {
            n5.setText(intent.getStringExtra("n5").toString())
        }
        if (datos != null) {
            accion = datos.getString("accion").toString()
        }
    }


    fun guardar(v: View?) {
        var nota1 = n1.text.toString().toFloat()
        var nota2 = n2.text.toString().toFloat()
        var nota3 = n3.text.toString().toFloat()
        var nota4 = n4.text.toString().toFloat()
        var nota5 = n5.text.toString().toFloat()
        var resultado = (nota1 + nota2 + nota3 + nota4 +nota5) / 5
        res.setText("Nota final: " + resultado)
        if (resultado >= 6){
            pas.setText("Aprobado")
        }else{
            pas.setText("Reprobado")
        }

        val nombre: String = nombre?.text.toString()
        val n1: String = n1?.text.toString()
        val n2: String = n2?.text.toString()
        val n3: String = n3?.text.toString()
        val n4: String = n4?.text.toString()
        val n5: String = n5?.text.toString()




        database=FirebaseDatabase.getInstance().getReference("notas")
// Se forma objeto persona
        val persona = Nota(nombre, n1,n2,n3,n4,n5)

        if (accion == "a") { //Agregar registro
            database.child(nombre).setValue(persona).addOnSuccessListener {
                Toast.makeText(this,"Se guardo con exito", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener{
                Toast.makeText(this,"Failed ", Toast.LENGTH_SHORT).show()
            }
        } else // Editar registro
        {
            val key = database.child("nombre").push().key
            if (key == null) {
                Toast.makeText(this,"Llave vacia", Toast.LENGTH_SHORT).show()
            }
            val personasValues = persona.toMap()
            val childUpdates = hashMapOf<String, Any>(
                "$nombre" to personasValues
            )
            database.updateChildren(childUpdates)
            Toast.makeText(this,"Se actualizo con exito", Toast.LENGTH_SHORT).show()
        }
        //finish()
    }

    fun promedio(){
        var nota1 = n1.text.toString().toFloat()
        var nota2 = n2.text.toString().toFloat()
        var nota3 = n3.text.toString().toFloat()
        var nota4 = n4.text.toString().toFloat()
        var nota5 = n5.text.toString().toFloat()
        var resultado = (nota1 + nota2 + nota3 + nota4 +nota5) / 5
        res.setText("Nota final: " + resultado)
        if (resultado >= 6){
            pas.setText("Aprobado")
        }else{
            pas.setText("Reprobado")
        }
    }

    fun cancelar(v: View?) {
        finish()
    }

}